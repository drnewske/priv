import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:or_streams/utils/app_theme.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:url_launcher/url_launcher.dart';

class SlideOutMenu extends StatelessWidget {
  const SlideOutMenu({super.key});

  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      // Could show a snackbar here if needed
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Drawer(
      backgroundColor: theme.colorScheme.surface,
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          _buildHeader(theme),
          _buildMenuItem(
            context,
            icon: Icons.info_outline,
            text: 'About Us',
            onTap: () {
              Navigator.pop(context);
              _showInfoDialog(context, title: 'About Us', content: 'O.R Streams: Your ultimate worship video app!');
            },
          ),
          _buildMenuItem(
            context,
            icon: Icons.copyright,
            text: 'Copyright',
            onTap: () {
              Navigator.pop(context);
              _showInfoDialog(context, title: 'Copyright', content: '© 2025 O.R Streams. All rights reserved.');
            },
          ),
          const Divider(),
          _buildMenuItem(
            context,
            icon: FontAwesomeIcons.telegram,
            text: 'Join on Telegram',
            color: const Color(0xFF2AABEE),
            onTap: () => _launchURL(AppConstants.telegramUrl),
          ),
          const Divider(),
          _buildMenuItem(
            context,
            icon: Icons.exit_to_app,
            text: 'Exit',
            color: AppTheme.primaryRed,
            onTap: () => SystemNavigator.pop(),
          ),
        ],
      ),
    );
  }
  
  Widget _buildHeader(ThemeData theme) {
    return DrawerHeader(
      decoration: BoxDecoration(
        color: theme.brightness == Brightness.dark ? AppTheme.appBlack : AppTheme.primaryRed,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            'Menu',
            style: theme.textTheme.headlineMedium?.copyWith(color: AppTheme.appWhite),
          ),
          const SizedBox(height: 4),
          Container(
            height: 3,
            width: 50,
            color: theme.brightness == Brightness.dark ? AppTheme.primaryRed : AppTheme.appWhite,
          )
        ],
      ),
    );
  }

  Widget _buildMenuItem(BuildContext context, {required IconData icon, required String text, required VoidCallback onTap, Color? color}) {
     final theme = Theme.of(context);
     final itemColor = color ?? theme.colorScheme.onSurface;

    return ListTile(
      leading: Icon(icon, color: itemColor),
      title: Text(
        text,
        style: theme.textTheme.titleMedium?.copyWith(color: itemColor),
      ),
      onTap: onTap,
    );
  }

  void _showInfoDialog(BuildContext context, {required String title, required String content}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
          actions: <Widget>[
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
