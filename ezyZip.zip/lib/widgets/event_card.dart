import 'dart:async';
import 'package:flutter/material.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/pages/stream_page.dart';
import 'package:or_streams/utils/app_theme.dart';

class EventCard extends StatefulWidget {
  final Event event;
  const EventCard({super.key, required this.event});

  @override
  State<EventCard> createState() => _EventCardState();
}

class _EventCardState extends State<EventCard> {
  Timer? _timer;
  String _statusText = '';
  bool _isFinished = false;

  @override
  void initState() {
    super.initState();
    _updateStatus();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        _updateStatus();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _updateStatus() {
    final now = DateTime.now().toUtc();
    final eventTime = widget.event.time;
    final kickOffEnd = eventTime.add(const Duration(minutes: 1));
    final liveEnd = eventTime.add(const Duration(hours: 2));

    String newStatus;
    if (now.isBefore(eventTime)) {
      final difference = eventTime.difference(now);
      newStatus = 'Starts in ${_formatCountdown(difference)}';
    } else if (now.isBefore(kickOffEnd)) {
      newStatus = 'KICK OFF!';
    } else if (now.isBefore(liveEnd)) {
      final difference = now.difference(eventTime);
      newStatus = 'LIVE ${_formatLiveDuration(difference)}';
    } else {
      newStatus = 'Finished';
      _isFinished = true;
    }
    
    if (mounted && _statusText != newStatus) {
      setState(() {
        _statusText = newStatus;
      });
    }
  }

  String _formatCountdown(Duration d) {
    if (d.isNegative) return "Starting";
    d = d + const Duration(seconds: 59);
    
    final days = d.inDays;
    final hours = d.inHours.remainder(24);
    final minutes = d.inMinutes.remainder(60);

    if (days > 0) return '$days d $hours h';
    if (hours > 0) return '$hours h $minutes m';
    if (minutes > 0) return '$minutes m';
    return "Starting";
  }

  String _formatLiveDuration(Duration d) {
    final hours = d.inHours;
    final minutes = d.inMinutes.remainder(60);
    if (hours > 0) {
      return '$hours:${minutes.toString().padLeft(2, '0')}';
    }
    return "${minutes.toString()}'";
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLive = _statusText.contains('LIVE') || _statusText.contains('KICK OFF');

    return AnimatedOpacity(
      opacity: _isFinished ? 0.6 : 1.0,
      duration: const Duration(milliseconds: 500),
      child: Card(
        elevation: 4,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
        child: InkWell(
          onTap: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => StreamPage(event: widget.event),
            ));
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
            color: theme.colorScheme.surface,
            child: Row(
              children: [
                _buildTeamDisplay(widget.event.group1Abbr, widget.event.group1),
                _buildVsAndStatus(isLive, theme),
                _buildTeamDisplay(widget.event.group2Abbr, widget.event.group2),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTeamDisplay(String abbr, String name) {
    return Expanded(
      flex: 3,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            abbr,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4.0),
            child: Text(
              name,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVsAndStatus(bool isLive, ThemeData theme) {
    return Expanded(
      flex: 2,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isLive ? AppTheme.primaryRed : theme.scaffoldBackgroundColor,
              border: isLive ? null : Border.all(color: theme.dividerColor)
            ),
            child: Text(
              'vs',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: isLive ? Colors.white : theme.textTheme.bodyLarge?.color,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _statusText,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: isLive ? AppTheme.primaryRed : theme.hintColor,
            ),
          ),
        ],
      ),
    );
  }
}
