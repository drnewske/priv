import 'package:flutter/material.dart';
import 'package:or_streams/pages/splash_screen.dart';
import 'package:or_streams/providers/data_provider.dart';
import 'package:or_streams/providers/theme_provider.dart';
import 'package:or_streams/services/cache_service.dart';
import 'package:provider/provider.dart';

void main() async {
  // Only the most essential, non-blocking setup should be in main().
  WidgetsFlutterBinding.ensureInitialized();
  
  final cacheService = CacheService();
  await cacheService.init();
  await cacheService.openBox();
  
  runApp(const ORStreamsApp());
}

class ORStreamsApp extends StatelessWidget {
  const ORStreamsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => DataProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            title: 'O.R STREAMS',
            theme: themeProvider.themeData,
            debugShowCheckedModeBanner: false,
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}
