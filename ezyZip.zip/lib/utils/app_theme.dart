import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // --- Color Palette ---
  static const Color primaryRed = Color(0xFFFF0000);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color appBlack = Color(0xFF000000);
  static const Color appWhite = Color(0xFFFFFFFF);
  static const Color lightGrey = Color(0xFFBDBDBD);
  static const Color darkGrey = Color(0xFF424242);

  // --- Light Theme Definition ---
  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: primaryRed,
    scaffoldBackgroundColor: appWhite,
    hintColor: Colors.grey[600],
    dividerColor: Colors.grey[300],
    colorScheme: const ColorScheme.light(
      primary: primaryRed,
      secondary: darkRed,
      surface: appWhite,
      onSurface: appBlack,
      error: darkRed,
      onError: appWhite,
    ),
    textTheme: GoogleFonts.poppinsTextTheme(
      const TextTheme(
        displayLarge: TextStyle(color: appBlack, fontWeight: FontWeight.bold),
        headlineSmall: TextStyle(color: appBlack, fontWeight: FontWeight.bold),
        titleLarge: TextStyle(color: appBlack, fontWeight: FontWeight.bold),
        titleMedium: TextStyle(color: appBlack),
        titleSmall: TextStyle(color: appBlack),
        bodyLarge: TextStyle(color: appBlack),
        bodyMedium: TextStyle(color: appBlack),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: primaryRed,
      foregroundColor: appWhite,
      elevation: 0,
      iconTheme: const IconThemeData(color: appWhite),
      // FIX: Added the missing const keyword
      titleTextStyle: GoogleFonts.poppins(
        textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: appWhite),
      )
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: appWhite,
      selectedItemColor: primaryRed,
      unselectedItemColor: appBlack,
    ),
  );

  // --- Dynamic Dark Theme Generator ---
  static ThemeData getDynamicDarkTheme(double dimness) {
    // dimness = 0.0 (almost black) -> 1.0 (lighter gray)
    final int grayValue = (20 + (30 * dimness)).round(); // from 20 to 50
    final Color backgroundColor = Color.fromARGB(255, grayValue, grayValue, grayValue);
    
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: primaryRed,
      scaffoldBackgroundColor: backgroundColor,
      hintColor: Colors.grey[400],
      dividerColor: Colors.grey[700],
      colorScheme: const ColorScheme.dark(
        primary: primaryRed,
        secondary: darkRed,
        surface: darkGrey,
        onSurface: appWhite,
        error: darkRed,
        onError: appWhite,
      ),
      textTheme: GoogleFonts.poppinsTextTheme(
        const TextTheme(
          displayLarge: TextStyle(color: appWhite, fontWeight: FontWeight.bold),
          headlineSmall: TextStyle(color: appWhite, fontWeight: FontWeight.bold),
          titleLarge: TextStyle(color: appWhite, fontWeight: FontWeight.bold),
          titleMedium: TextStyle(color: appWhite),
          titleSmall: TextStyle(color: appWhite),
          bodyLarge: TextStyle(color: appWhite),
          bodyMedium: TextStyle(color: appWhite),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: appBlack,
        foregroundColor: appWhite,
        elevation: 0,
        iconTheme: const IconThemeData(color: primaryRed),
        titleTextStyle: GoogleFonts.poppins(
          textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: appWhite),
        )
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: appBlack,
        selectedItemColor: primaryRed,
        unselectedItemColor: appWhite,
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primaryRed,
        inactiveTrackColor: Colors.grey[800],
        thumbColor: primaryRed,
        overlayColor: primaryRed.withAlpha(50),
      ),
    );
  }
}
