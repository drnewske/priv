class AppConstants {
  static const String orStreamsUrl = 'https://orstreams.online';
  static const String matchesApiUrl = 'https://orstreams.online/matches-api/';
  static const String telegramUrl = 'https://t.me/+37u6NHt-LN8wMjlk';

  static const String appIcon = 'assets/images/icono.jpg';
  static const String channelsAsset = 'assets/channels.json';

  static const String periodicFetchTaskName = "or_streams.task.periodicFetch";
  static const String liveCheckTaskName = "or_streams.task.liveCheck";

  static const String liveEventChannelId = 'live_event_channel';
  static const String liveEventChannelName = 'Live Events';
  static const String liveEventChannelDesc = 'Notifications for when worship events go live.';

  static const String themePreferenceKey = 'theme_preference';
  static const String dimnessPreferenceKey = 'dimness_preference';
  static const String autoRotatePreferenceKey = 'auto_rotate_preference';
}
