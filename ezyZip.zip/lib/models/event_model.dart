import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

part 'event_model.g.dart';

@HiveType(typeId: 0)
class Event extends HiveObject {
  @HiveField(0)
  final String group1;

  @HiveField(1)
  final String group2;

  @HiveField(2)
  final DateTime time;

  @HiveField(3)
  final List<String> urls;

  @HiveField(4)
  final DateTime timestamp;

  @HiveField(5)
  final String date;

  String get group1Abbr => _generateAbbreviation(group1);
  String get group2Abbr => _generateAbbreviation(group2);

  Event({
    required this.group1,
    required this.group2,
    required this.time,
    required this.urls,
    required this.timestamp,
    required this.date,
  });

  factory Event.fromApiJson(Map<String, dynamic> json, DateTime fetchTimestamp) {
    final dateStr = json['date'] as String;
    final timeStr = json['time'] as String;
    final format = DateFormat("dd-MM-yyyyHH:mm");
    final eventDateTime = format.parseUtc('$dateStr$timeStr');

    return Event(
      group1: json['team1'] as String,
      group2: json['team2'] as String,
      time: eventDateTime,
      urls: List<String>.from(json['links']),
      timestamp: fetchTimestamp,
      date: dateStr,
    );
  }

  String _generateAbbreviation(String name) {
    if (name.isEmpty) return '';
    final words = name.split(' ').where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return '';
    
    String abbr = '';
    for (var word in words) {
      if (abbr.length < 3) {
        abbr += word[0].toUpperCase();
      }
    }
    return abbr;
  }

  bool isLive() {
    final now = DateTime.now().toUtc();
    final endTime = time.add(const Duration(hours: 2));
    return now.isAfter(time) && now.isBefore(endTime);
  }
}
