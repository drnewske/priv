class Channel {
  final String name;
  final String logo;
  final String description;
  final String url;

  Channel({
    required this.name,
    required this.logo,
    required this.description,
    required this.url,
  });

  factory Channel.fromJson(Map<String, dynamic> json) {
    return Channel(
      name: json['name'] ?? 'Unnamed Channel',
      logo: json['logo'] ?? 'assets/images/placeholder.png', // Fallback logo
      description: json['description'] ?? 'No description available.',
      url: json['url'] ?? '',
    );
  }
}
