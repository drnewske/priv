// ===============================================================
// File: lib/services/api_service.dart
// ===============================================================
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/utils/constants.dart';

class ApiService {
  Future<List<Event>> fetchAndParseEvents() async {
    try {
      final headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      };
      final response = await http.get(Uri.parse(AppConstants.matchesApiUrl), headers: headers);

      if (response.statusCode == 200) {
        if (response.body.isEmpty) return [];
        
        final List<dynamic> decodedList = json.decode(response.body);
        final now = DateTime.now().toUtc();
        
        return decodedList
            .map((item) {
              try {
                return Event.fromApiJson(item, now);
              } catch (e) {
                return null;
              }
            })
            .whereType<Event>()
            .toList();
      } else {
        throw Exception('Server Error: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Could not fetch events: $e');
    }
  }
}