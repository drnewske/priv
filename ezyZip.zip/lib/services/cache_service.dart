// --- File: lib/services/cache_service.dart ---

import 'package:hive_flutter/hive_flutter.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:path_provider/path_provider.dart';

class CacheService {
  static const String _boxName = 'eventsBox';

  Future<void> init() async {
    final directory = await getApplicationDocumentsDirectory();
    await Hive.initFlutter(directory.path);
    if (!Hive.isAdapterRegistered(EventAdapter().typeId)) {
       Hive.registerAdapter(EventAdapter());
    }
  }

  Future<void> openBox() async {
    await Hive.openBox<Event>(_boxName);
  }

  Future<void> saveEvents(List<Event> events) async {
    final box = Hive.box<Event>(_boxName);
    await box.clear();
    await box.addAll(events);
  }

  List<Event> getEvents() {
    final box = Hive.box<Event>(_boxName);
    return box.values.toList();
  }

  bool isCacheValid() {
    final box = Hive.box<Event>(_boxName);
    if (box.isEmpty) return false;
    final firstEvent = box.getAt(0);
    if (firstEvent == null) return false;
    final now = DateTime.now();
    final cacheTime = firstEvent.timestamp;
    final difference = now.difference(cacheTime);
    return difference.inHours < 4;
  }

  Future<void> clearCache() async {
    final box = Hive.box<Event>(_boxName);
    await box.clear();
  }
}