// --- File: lib/services/background_service.dart ---

import 'package:workmanager/workmanager.dart';
import 'package:or_streams/services/api_service.dart';
import 'package:or_streams/services/cache_service.dart';
import 'package:or_streams/utils/constants.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    final cacheService = CacheService();
    await cacheService.init();
    await cacheService.openBox();
    final apiService = ApiService();

    try {
      final events = await apiService.fetchAndParseEvents();
      await cacheService.saveEvents(events);
      return Future.value(true);
    } catch (e) {
      return Future.value(false);
    }
  });
}

class BackgroundService {
  Future<void> initializeAndRegister() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await Workmanager().registerPeriodicTask(
      "1",
      AppConstants.periodicFetchTaskName,
      frequency: const Duration(hours: 4),
      constraints: Constraints(networkType: NetworkType.connected),
    );
  }
}