import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/utils/constants.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/icono');

    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);
  }

  Future<void> requestPermissions() async {
    await _plugin
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
  }

  Future<void> showLiveEventNotification(Event event) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      AppConstants.liveEventChannelId,
      AppConstants.liveEventChannelName,
      channelDescription: AppConstants.liveEventChannelDesc,
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
    );

    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(badgeNumber: 1),
    );

    await _plugin.show(
      event.hashCode,
      'Event Starting Now!',
      '${event.group1} vs ${event.group2} already started!!',
      notificationDetails,
    );
  }
}
