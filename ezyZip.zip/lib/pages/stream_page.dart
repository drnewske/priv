
// ===============================================================
// File: lib/pages/stream_page.dart
// ===============================================================
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:or_streams/models/channel_model.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/providers/data_provider.dart';
import 'package:or_streams/utils/app_theme.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:or_streams/widgets/event_card.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'dart:convert';

class StreamPage extends StatefulWidget {
  final Event event;

  const StreamPage({super.key, required this.event});

  @override
  State<StreamPage> createState() => _StreamPageState();
}

class _StreamPageState extends State<StreamPage> with SingleTickerProviderStateMixin {
  late final WebViewController _controller;
  late AnimationController _animationController;
  late Animation<double> _animation;
  
  late Event _currentEvent;
  bool _isWebViewLoading = true;
  int _selectedUrlIndex = 0;
  bool _autoRotate = false;
  bool _isFullScreen = false;

  bool get isChannel => _currentEvent.group2.isEmpty;
  String get pageTitle => isChannel ? _currentEvent.group1 : '${_currentEvent.group1} vs ${_currentEvent.group2}';

  @override
  void initState() {
    super.initState();
    _currentEvent = widget.event;
    _loadSettingsAndInitPlayer();
  }
  
  void _loadSettingsAndInitPlayer() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      _autoRotate = prefs.getBool(AppConstants.autoRotatePreferenceKey) ?? false;
      _setOrientation();
    }

    _animationController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _animationController, curve: Curves.easeInOut));
    
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) => setState(() => _isWebViewLoading = true),
          onPageFinished: (String url) => setState(() => _isWebViewLoading = false),
          onWebResourceError: (WebResourceError error) => setState(() => _isWebViewLoading = false),
          onNavigationRequest: (NavigationRequest request) {
            if (request.isMainFrame && request.url != _currentEvent.urls[_selectedUrlIndex]) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      );

    if (WebViewPlatform.instance is AndroidWebViewPlatform) {
      final platformController = _controller.platform as AndroidWebViewController;
      platformController.setMediaPlaybackRequiresUserGesture(false);
      platformController.setOnPlatformPermissionRequest((request) => request.grant());
    }
    
    if (_currentEvent.urls.isNotEmpty) {
      _controller.loadRequest(Uri.parse(_currentEvent.urls[0]));
    }
  }
  
  void _setOrientation() {
    if (_autoRotate) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    }
  }

  void _toggleFullScreen() {
      setState(() {
        _isFullScreen = !_isFullScreen;
        if (_isFullScreen) {
            SystemChrome.setPreferredOrientations([
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
            ]);
        } else {
            _setOrientation();
        }
      });
  }

  void _updateStream(Event newEvent) {
    setState(() {
      _currentEvent = newEvent;
      _selectedUrlIndex = 0;
      if (newEvent.urls.isNotEmpty) {
        _isWebViewLoading = true;
        _controller.loadRequest(Uri.parse(newEvent.urls[0]));
      }
    });
  }

  @override
  void dispose() {
    // Definitive fix for the audio leak bug
    _controller.loadRequest(Uri.parse("about:blank"));
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    _animationController.dispose();
    super.dispose();
  }

  void _onStreamButtonPressed(int index) {
    if (index >= 0 && index < _currentEvent.urls.length) {
      setState(() => _selectedUrlIndex = index);
      _controller.loadRequest(Uri.parse(_currentEvent.urls[index]));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isFullScreen) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: _buildVideoPlayer()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(pageTitle, style: const TextStyle(fontSize: 18))),
      body: Column(
        children: [
          _buildVideoPlayer(),
          if (_currentEvent.urls.length > 1) _buildStreamButtons(),
          _buildRelatedContentSection(),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        final startColor = Color.lerp(AppTheme.primaryRed.withAlpha(128), AppTheme.primaryRed, _animation.value)!;
        final endColor = Color.lerp(AppTheme.darkRed, AppTheme.darkRed.withAlpha(128), _animation.value)!;

        return Container(
          margin: const EdgeInsets.all(8.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.0),
            gradient: LinearGradient(colors: [startColor, endColor]),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Stack(
                children: [
                  WebViewWidget(controller: _controller),
                  if (_isWebViewLoading) const Center(child: CircularProgressIndicator(color: AppTheme.appWhite)),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Material(
                      color: Colors.black.withAlpha(128),
                      borderRadius: BorderRadius.circular(20),
                      child: InkWell(
                        onTap: _toggleFullScreen,
                        child: Padding(
                          padding: const EdgeInsets.all(6.0),
                          child: Icon(
                            _isFullScreen ? Icons.fullscreen_exit : Icons.fullscreen,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStreamButtons() {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: SizedBox(
        height: 40,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: _currentEvent.urls.length,
          itemBuilder: (context, index) {
            final isSelected = index == _selectedUrlIndex;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4.0),
              child: ElevatedButton(
                onPressed: () => _onStreamButtonPressed(index),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isSelected ? theme.colorScheme.primary : theme.colorScheme.surface,
                  foregroundColor: isSelected ? Colors.white : theme.colorScheme.onSurface,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0)),
                  padding: const EdgeInsets.symmetric(horizontal: 20)
                ),
                child: Text('Stream ${index + 1}'),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildRelatedContentSection() {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 8.0),
            child: Text(
              isChannel ? 'Other Channels' : 'Related Events',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
          Expanded(child: isChannel ? _buildOtherChannelsList() : _buildRelatedEventsList()),
        ],
      ),
    );
  }

  Widget _buildRelatedEventsList() {
    final allEvents = Provider.of<DataProvider>(context, listen: false).events;
    final relatedEvents = allEvents.where((e) => e.group2.isNotEmpty && e.hashCode != _currentEvent.hashCode && (e.isLive() || e.time.isAfter(DateTime.now().toUtc()))).take(5).toList();
    if (relatedEvents.isEmpty) {
      return const Center(child: Text("No other live or upcoming events."));
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      itemCount: relatedEvents.length,
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(bottom: 8.0),
        child: EventCard(event: relatedEvents[index]),
      )
    );
  }

  Widget _buildOtherChannelsList() {
    return FutureBuilder<List<Channel>>(
      future: rootBundle.loadString(AppConstants.channelsAsset).then((json) =>
          (jsonDecode(json)['channels'] as List)
              .map((c) => Channel.fromJson(c))
              .where((c) => c.name != _currentEvent.group1)
              .take(3)
              .toList()
      ),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        if (snapshot.data!.isEmpty) return const Center(child: Text("No other channels available."));
        return ListView.separated(
          itemCount: snapshot.data!.length,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          separatorBuilder: (context, index) => const Divider(),
          itemBuilder: (context, index) {
            final channel = snapshot.data![index];
            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(channel.logo, width: 50, height: 50, fit: BoxFit.cover, errorBuilder: (c, e, s) => const Icon(Icons.tv)),
                ),
                title: Text(channel.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(channel.description, maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () {
                   final mockEvent = Event(group1: channel.name, group2: '', time: DateTime.now(), urls: [channel.url], timestamp: DateTime.now(), date: '');
                   _updateStream(mockEvent);
                },
              ),
            );
          },
        );
      },
    );
  }
}

