// --- File: lib/pages/church_channels_page.dart (Corrected) ---

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:or_streams/models/channel_model.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/pages/stream_page.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:or_streams/widgets/slide_out_menu.dart';

class ChurchChannelsPage extends StatefulWidget {
  const ChurchChannelsPage({super.key});

  @override
  State<ChurchChannelsPage> createState() => _ChurchChannelsPageState();
}

class _ChurchChannelsPageState extends State<ChurchChannelsPage> {
  late Future<List<Channel>> _channelsFuture;

  @override
  void initState() {
    super.initState();
    _channelsFuture = _loadChannels();
  }

  Future<List<Channel>> _loadChannels() async {
    try {
      final String response = await rootBundle.loadString(AppConstants.channelsAsset);
      final data = json.decode(response);
      return (data['channels'] as List).map((json) => Channel.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SlideOutMenu(),
      body: FutureBuilder<List<Channel>>(
        future: _channelsFuture,
        builder: (context, snapshot) {
          return CustomScrollView(
            slivers: [
              const SliverAppBar(title: Text('Church Channels'), pinned: true),
              if (snapshot.connectionState == ConnectionState.waiting)
                const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
              else if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty)
                const SliverFillRemaining(child: Center(child: Text('No channels available.')))
              else
                _buildChannelsGrid(snapshot.data!),
            ],
          );
        },
      ),
    );
  }

  Widget _buildChannelsGrid(List<Channel> channels) {
    return SliverPadding(
      padding: const EdgeInsets.all(12.0),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 500,
          childAspectRatio: 3.5,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        delegate: SliverChildBuilderDelegate(
          (context, index) => _buildChannelCard(channels[index]),
          childCount: channels.length,
        ),
      ),
    );
  }

  Widget _buildChannelCard(Channel channel) {
    final theme = Theme.of(context);
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          // FIX: This now matches the corrected Event constructor.
          final mockEvent = Event(
            group1: channel.name,
            group2: '',
            time: DateTime.now(),
            urls: [channel.url],
            timestamp: DateTime.now(),
            date: '',
          );
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => StreamPage(event: mockEvent),
          ));
        },
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              Image.asset(
                channel.logo, width: 60, height: 60,
                errorBuilder: (c, e, s) => const Icon(Icons.tv, size: 60),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      channel.name,
                      style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      channel.description,
                      style: theme.textTheme.bodyMedium?.copyWith(color: theme.hintColor),
                      maxLines: 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
