
// ===============================================================
// File: lib/pages/worship_song_competition_page.dart
// ===============================================================
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/providers/data_provider.dart';
import 'package:or_streams/providers/theme_provider.dart';
import 'package:or_streams/widgets/event_card.dart';
import 'package:or_streams/widgets/slide_out_menu.dart';
import 'package:provider/provider.dart';

class WorshipSongCompetitionPage extends StatefulWidget {
  const WorshipSongCompetitionPage({super.key});

  @override
  State<WorshipSongCompetitionPage> createState() => _WorshipSongCompetitionPageState();
}

class _WorshipSongCompetitionPageState extends State<WorshipSongCompetitionPage> {
  final TextEditingController _searchController = TextEditingController();
  List<Event> _filteredEvents = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_filterEvents);
    WidgetsBinding.instance.addPostFrameCallback((_) => _filterEvents());
  }
  
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _filterEvents();
  }

  @override
  void dispose() {
    _searchController.removeListener(_filterEvents);
    _searchController.dispose();
    super.dispose();
  }

  void _filterEvents() {
    if (!mounted) return;
    final dataProvider = Provider.of<DataProvider>(context, listen: false);
    final allEvents = dataProvider.events;
    final query = _searchController.text.toLowerCase();
    
    final newFilteredList = query.isEmpty
        ? allEvents
        : allEvents.where((event) =>
              event.group1.toLowerCase().contains(query) ||
              event.group2.toLowerCase().contains(query)).toList();

    if (!listEquals(_filteredEvents, newFilteredList)) {
        setState(() {
            _filteredEvents = newFilteredList;
        });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();

    return Scaffold(
      drawer: const SlideOutMenu(),
      body: RefreshIndicator(
        onRefresh: () => dataProvider.loadEvents(forceRefresh: true),
        child: CustomScrollView(
          slivers: [
            _buildSliverAppBar(),
            if (dataProvider.isLoading && _filteredEvents.isEmpty)
              const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_filteredEvents.isEmpty)
              SliverFillRemaining(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      dataProvider.hasError
                        ? "Could not connect to server.\nPlease check your internet and pull to refresh."
                        : "No events found.",
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.grey),
                    ),
                  ),
                ),
              )
            else
              _buildSliverList(),
          ],
        ),
      ),
    );
  }

  SliverAppBar _buildSliverAppBar() {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;

    return SliverAppBar(
      title: const Text('O.R STREAMS'),
      pinned: true,
      floating: true,
      backgroundColor: theme.appBarTheme.backgroundColor,
      actions: [
        IconButton(
          icon: Icon(isDarkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round_outlined),
          onPressed: () => themeProvider.toggleTheme(),
        ),
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: () => Provider.of<DataProvider>(context, listen: false).loadEvents(forceRefresh: true),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(60.0),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 12.0),
          child: _buildSearchBar(),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    final theme = Theme.of(context);
    return TextField(
      controller: _searchController,
      decoration: InputDecoration(
        hintText: 'Search events...',
        hintStyle: TextStyle(color: theme.hintColor),
        prefixIcon: Icon(Icons.search, color: theme.colorScheme.primary),
        suffixIcon: _searchController.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear),
                onPressed: () => _searchController.clear(),
              )
            : null,
        filled: true,
        fillColor: theme.colorScheme.surface,
        contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: BorderSide(color: theme.colorScheme.primary, width: 2.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: BorderSide(color: theme.dividerColor, width: 1.0),
        ),
      ),
    );
  }

  Widget _buildSliverList() {
    return SliverPadding(
      padding: const EdgeInsets.all(8.0),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: EventCard(event: _filteredEvents[index]),
            );
          },
          childCount: _filteredEvents.length,
        ),
      ),
    );
  }
}