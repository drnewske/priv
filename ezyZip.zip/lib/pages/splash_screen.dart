import 'dart:async';
import 'package:flutter/material.dart';
import 'package:or_streams/pages/main_shell.dart';
import 'package:or_streams/providers/data_provider.dart';
import 'package:or_streams/services/background_service.dart';
import 'package:or_streams/services/notification_service.dart';
import 'package:or_streams/utils/app_theme.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:provider/provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String _typedTitle = '';
  Timer? _typingTimer;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    super.dispose();
  }
  
  Future<void> _initializeApp() async {
    // Start the visual animations immediately
    _startTypingAnimation();
    
    // Get the provider, but don't listen here
    final dataProvider = Provider.of<DataProvider>(context, listen: false);
    
    // Now, perform all heavy initializations safely in the background.
    // The UI is already visible while these are running.
    await NotificationService().init();
    await BackgroundService().initializeAndRegister();

    // The data loading and the 10-second delay will run in parallel.
    // The app will wait for whichever takes longer to finish.
    await Future.wait([
      dataProvider.loadEvents(),
      Future.delayed(const Duration(seconds: 10)),
    ]);
    
    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const MainShell(),
          transitionsBuilder: (_, animation, __, child) =>
              FadeTransition(opacity: animation, child: child),
        ),
      );
    }
  }

  void _startTypingAnimation() {
    const targetTitle = "O.R STREAMS";
    int currentIndex = 0;
    _typingTimer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      if (currentIndex < targetTitle.length) {
        if (mounted) {
          setState(() => _typedTitle = targetTitle.substring(0, currentIndex + 1));
          currentIndex++;
        }
      } else {
        timer.cancel();
      }
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryRed,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(24.0),
              child: Image.asset(
                AppConstants.appIcon,
                width: 120,
                height: 120,
              ),
            ),
            const SizedBox(height: 30),
            Text(
              _typedTitle,
              style: const TextStyle(
                fontFamily: 'Poppins',
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 50),
            Consumer<DataProvider>(
              builder: (context, dataProvider, child) {
                final messages = ["Starting app...", "Getting ready...", "Finalising...", "Welcome..."];
                int messageIndex = messages.indexOf(dataProvider.loadingMessage);
                double progress = (messageIndex >= 0) ? (messageIndex + 1) / messages.length : 0.0;

                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 50.0),
                  child: Column(
                    children: [
                      Text(
                        dataProvider.loadingMessage,
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                      ),
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: AppTheme.darkRed.withAlpha(150),
                          valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                          minHeight: 8,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
