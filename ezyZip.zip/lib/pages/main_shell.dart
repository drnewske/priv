// --- File: lib/pages/main_shell.dart (Corrected) ---

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:or_streams/pages/church_channels_page.dart';
import 'package:or_streams/pages/our_site_page.dart';
import 'package:or_streams/pages/settings_page.dart';
import 'package:or_streams/pages/worship_song_competition_page.dart';
import 'package:or_streams/utils/app_theme.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;
  DateTime? _lastPressedAt;

  static final List<Widget> _pages = <Widget>[
    const WorshipSongCompetitionPage(),
    const ChurchChannelsPage(),
    const OurSitePage(),
    const SettingsPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      // FINAL FIX: Changed the property name to 'onPopInvokedWithResult'
      onPopInvokedWithResult: (bool didPop, dynamic result) {
        if (didPop) {
          return;
        }
        _handleBackButton();
      },
      child: Scaffold(
        body: IndexedStack(
          index: _selectedIndex,
          children: _pages,
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.futbol),
              label: 'LIVE EVENTS',
            ),
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.tv),
              label: 'TV CHANNELS',
            ),
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.globe),
              label: 'Our Site',
            ),
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.gear),
              label: 'Settings',
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          iconSize: 24,
          selectedFontSize: 12,
          unselectedFontSize: 12,
        ),
      ),
    );
  }

  void _handleBackButton() {
    final now = DateTime.now();
    if (_lastPressedAt != null &&
        now.difference(_lastPressedAt!) < const Duration(seconds: 2)) {
      SystemNavigator.pop();
    } else {
      _lastPressedAt = now;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Press again to exit'),
            duration: const Duration(seconds: 2),
            backgroundColor: AppTheme.darkGrey,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
          ),
        );
      }
    }
  }
}