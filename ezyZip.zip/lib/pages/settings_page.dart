// --- File: lib/pages/settings_page.dart ---

import 'package:flutter/material.dart';
import 'package:or_streams/providers/data_provider.dart';
import 'package:or_streams/providers/theme_provider.dart';
import 'package:or_streams/utils/app_theme.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _autoRotate = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _autoRotate = prefs.getBool(AppConstants.autoRotatePreferenceKey) ?? false;
      });
    }
  }

  void _saveAutoRotate(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.autoRotatePreferenceKey, value);
    setState(() {
      _autoRotate = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildThemeControlCard(themeProvider, theme),
          const SizedBox(height: 20),
          _buildGeneralSettingsCard(theme),
          const SizedBox(height: 20),
          _buildAboutCard(context),
        ],
      ),
    );
  }

  Widget _buildThemeControlCard(ThemeProvider themeProvider, ThemeData theme) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          children: [
            SwitchListTile(
              title: Text('Dark Mode', style: theme.textTheme.titleMedium),
              value: themeProvider.isDarkMode,
              onChanged: (value) => themeProvider.toggleTheme(),
              secondary: const Icon(Icons.brightness_6_outlined),
              activeColor: AppTheme.primaryRed,
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: themeProvider.isDarkMode ? 70 : 0,
              child: ClipRRect(
                child: themeProvider.isDarkMode
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 8.0),
                            child: Text('Dimness Level', style: theme.textTheme.titleSmall),
                          ),
                          Slider(
                            value: themeProvider.dimnessLevel,
                            onChanged: (newDimness) {
                              themeProvider.setDimness(newDimness);
                            },
                            min: 0.0,
                            max: 1.0,
                          ),
                        ],
                      )
                    : const SizedBox.shrink(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGeneralSettingsCard(ThemeData theme) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: Column(
        children: [
          SwitchListTile(
            title: Text('Auto-rotate streams', style: theme.textTheme.titleMedium),
            value: _autoRotate,
            onChanged: _saveAutoRotate,
            secondary: const Icon(Icons.screen_rotation_outlined),
            activeColor: AppTheme.primaryRed,
          ),
          const Divider(height: 1, indent: 72),
          ListTile(
            leading: const Icon(Icons.delete_sweep_outlined),
            title: const Text('Clear Cache'),
            subtitle: const Text('Removes saved event data'),
            onTap: () => _showClearCacheConfirmation(context),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutCard(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: Column(
        children: [
           ListTile(
            leading: const Icon(Icons.send_outlined, color: Color(0xFF2AABEE)),
            title: const Text('Join us on Telegram'),
            onTap: () => _launchURL(AppConstants.telegramUrl),
          ),
          const Divider(height: 1, indent: 72),
          ListTile(
            leading: const Icon(Icons.share_outlined),
            title: const Text('Share App'),
            onTap: () {
              Share.share('Check out the O.R Streams app! <Your App Link Here>');
            },
          ),
        ],
      ),
    );
  }

  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch $url')),
        );
      }
    }
  }

  void _showClearCacheConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Confirm'),
          content: const Text('Are you sure you want to clear the cache? The app will fetch new data.'),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(dialogContext).pop(),
            ),
            TextButton(
              child: const Text('Clear', style: TextStyle(color: AppTheme.primaryRed)),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _clearCacheAndRefresh(context);
              },
            ),
          ],
        );
      },
    );
  }

  void _clearCacheAndRefresh(BuildContext context) async {
    final dataProvider = Provider.of<DataProvider>(context, listen: false);
    await dataProvider.clearCache();

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cache cleared. Refreshing data...'),
          backgroundColor: AppTheme.darkGrey,
        ),
      );
    }
  }
}
