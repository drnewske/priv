// ===============================================================
// File: lib/providers/data_provider.dart
// ===============================================================
import 'package:flutter/foundation.dart';
import 'package:or_streams/models/event_model.dart';
import 'package:or_streams/services/api_service.dart';
import 'package:or_streams/services/background_service.dart';
import 'package:or_streams/services/cache_service.dart';
import 'package:or_streams/services/notification_service.dart';

class DataProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  final CacheService _cacheService = CacheService();
  final NotificationService _notificationService = NotificationService();
  final BackgroundService _backgroundService = BackgroundService();

  List<Event> _events = [];
  bool _isLoading = true; // Start in loading state
  String _loadingMessage = 'Starting app...';
  bool _hasError = false;

  List<Event> get events => _events;
  bool get isLoading => _isLoading;
  String get loadingMessage => _loadingMessage;
  bool get hasError => _hasError;

  DataProvider();
  
  Future<void> loadEvents({bool forceRefresh = false}) async {
    _setLoading(true, "Getting ready...");
    _hasError = false;

    try {
      await _notificationService.init();
      await _backgroundService.initializeAndRegister();

      if (!forceRefresh && _cacheService.isCacheValid()) {
        _events = _cacheService.getEvents();
        if (_events.isNotEmpty) {
          _filterAndSortEvents();
          _setLoading(false, "Welcome...");
          return;
        }
      }

      _setLoading(true, "Finalising...");
      _events = await _apiService.fetchAndParseEvents();
      await _cacheService.saveEvents(_events);
      _filterAndSortEvents();

    } catch (e) {
      _hasError = true;
      _events = _cacheService.getEvents();
      _filterAndSortEvents();
    } finally {
      _setLoading(false, "Welcome...");
    }
  }

  Future<void> clearCache() async {
    await _cacheService.clearCache();
    _events = [];
    notifyListeners();
    await loadEvents(forceRefresh: true);
  }

  void _setLoading(bool loading, String message) {
    _isLoading = loading;
    _loadingMessage = message;
    notifyListeners();
  }

  void _filterAndSortEvents() {
    final now = DateTime.now().toUtc();
    _events.removeWhere((event) {
      final finishedTime = event.time.add(const Duration(hours: 2, minutes: 30));
      return now.isAfter(finishedTime);
    });

    _events.sort((a, b) {
      if (a.isLive() && !b.isLive()) return -1;
      if (!a.isLive() && b.isLive()) return 1;
      return a.time.compareTo(b.time);
    });
  }
}