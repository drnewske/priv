// --- File: lib/providers/theme_provider.dart ---

import 'package:flutter/material.dart';
import 'package:or_streams/utils/app_theme.dart';
import 'package:or_streams/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeData _themeData = AppTheme.lightTheme;
  bool _isDarkMode = false;
  double _dimnessLevel = 0.0;

  ThemeData get themeData => _themeData;
  bool get isDarkMode => _isDarkMode;
  double get dimnessLevel => _dimnessLevel;

  ThemeProvider() {
    _loadTheme();
  }

  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    _updateTheme();
  }
  
  void setDimness(double level) {
    _dimnessLevel = level.clamp(0.0, 1.0);
    _updateTheme();
  }

  void _updateTheme() {
    _themeData = _isDarkMode ? AppTheme.getDynamicDarkTheme(_dimnessLevel) : AppTheme.lightTheme;
    _savePreferences();
    notifyListeners();
  }

  void _savePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.themePreferenceKey, _isDarkMode);
    await prefs.setDouble(AppConstants.dimnessPreferenceKey, _dimnessLevel);
  }

  void _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool(AppConstants.themePreferenceKey) ?? false;
    _dimnessLevel = prefs.getDouble(AppConstants.dimnessPreferenceKey) ?? 0.0;
    _updateTheme();
  }
}
